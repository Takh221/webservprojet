package com.example.bibliotheque.controller;

import com.example.bibliotheque.model.Livre;
import com.example.bibliotheque.repository.LivreRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/livres")
public class LivreController {
    private final LivreRepository repo;

    public LivreController(LivreRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Livre> getAll() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public Livre getById(@PathVariable Long id) {
        return repo.findById(id).orElse(null);
    }

    @GetMapping("/disponibles")
    public List<Livre> getDisponibles() {
        return repo.findByDisponibleTrue();
    }
}