# Projet Bibliothèque Universitaire Hybride

## Objectif
Créer un système de gestion de bibliothèque avec :
- Une API REST pour les utilisateurs finaux (étudiants, professeurs)
- Une API SOAP pour les bibliothécaires (gestion interne)

## Tech stack
- Java + Spring Boot
- H2 database (en mémoire)
- REST (via @RestController)
- SOAP (via Apache CXF et @WebService)
- Testable avec Postman et SoapUI

## Endpoints REST
- `GET /livres` – Liste des livres
- `GET /livres/{id}` – Détail d’un livre
- `GET /livres/disponibles` – Livres disponibles

## SOAP Web Services
- `ajouterLivre(titre, auteur)`
- `modifierLivre(id, titre, auteur)`
- `supprimerLivre(id)`

## Démarrer le projet
```bash
./mvnw spring-boot:run
```
Accès H2 console : `http://localhost:8080/h2-console`

## Tests
- REST via Postman
- SOAP via SoapUI : `http://localhost:8080/services/soap/livre?wsdl`