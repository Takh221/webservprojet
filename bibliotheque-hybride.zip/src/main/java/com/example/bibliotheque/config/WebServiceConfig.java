package com.example.bibliotheque.config;

import com.example.bibliotheque.soap.LivreSoapService;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.ws.Endpoint;
import org.apache.cxf.Bus;

@Configuration
public class WebServiceConfig {
    @Bean
    public Endpoint endpoint(Bus bus, LivreSoapService service) {
        EndpointImpl endpoint = new EndpointImpl(bus, service);
        endpoint.publish("/soap/livre");
        return endpoint;
    }
}