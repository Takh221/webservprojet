package com.example.bibliotheque.soap;

import com.example.bibliotheque.model.Livre;
import com.example.bibliotheque.repository.LivreRepository;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(serviceName = "BibliothecaireService")
@Service
public class LivreSoapService {

    private final LivreRepository repo;

    public LivreSoapService(LivreRepository repo) {
        this.repo = repo;
    }

    @WebMethod
    public Livre ajouterLivre(String titre, String auteur) {
        Livre livre = new Livre(null, titre, auteur, true);
        return repo.save(livre);
    }

    @WebMethod
    public Livre modifierLivre(Long id, String titre, String auteur) {
        Livre livre = repo.findById(id).orElse(null);
        if (livre != null) {
            livre.setTitre(titre);
            livre.setAuteur(auteur);
            return repo.save(livre);
        }
        return null;
    }

    @WebMethod
    public void supprimerLivre(Long id) {
        repo.deleteById(id);
    }
}